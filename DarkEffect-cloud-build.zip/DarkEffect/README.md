# DARK EFFECT

Android video editor (Kotlin, Jetpack Compose, Media3). Dark UI, neon purple and electric blue accents.

## Build and run
1. Open the `DarkEffect` folder in Android Studio Koala (2024.1) or newer.
2. Let Gradle sync (JDK 17, Android SDK 34). If the wrapper is missing, run `gradle wrapper` once.
3. Run on a device or emulator with Android 8.0 (API 26) or newer.

## What works
- Home: logo, New Project, Import (photo picker, videos and images), recent projects, settings.
- Import copies media into app storage, so projects still open after the source is moved or deleted.
- Editor: preview (video), multi-track timeline (video, text, audio), zoom with pinch or +/-, draggable ruler playhead, play/pause, undo/redo (up to 100 steps), autosave.
- Clip tools: split at playhead, trim (range slider), delete, reorder, crop (16:9, 9:16, 1:1, 4:5).
- Color: brightness, contrast, saturation, exposure, plus presets.
- Grading that renders on export: Teal and Orange, Noir, Warm Cinema.
- Keyframes: stored per clip and shown as markers. Not applied on export yet.
- Export: 720p or 1080p, 24/30/60 fps, progress bar, save to Movies/DARK EFFECT.

## Still incomplete
- Glow, cinematic blur, RGB split, glitch, shake, VHS, velocity: catalogued in the Effects screen, but the GPU shaders are not written.
- Text layers: shown on the timeline, but no text editing UI and not rendered on export.
- Audio layers: shown on the timeline, but not mixed into the export.
- Keyframe animation (position, scale, rotation, opacity): stored only.
- Transitions between clips: not implemented.
- Image clips: included in export; preview shows a still frame instead of playing.
- Preview does not show color grades; grades appear in the exported file.

## Notes
- Photo picker is used for import, so no read permission is needed on Android 13+.
- On Android 9 and below, saving to Gallery needs the storage permission.
- The code has not been compiled or run on a device yet. Expect a round of small fixes on first build.
