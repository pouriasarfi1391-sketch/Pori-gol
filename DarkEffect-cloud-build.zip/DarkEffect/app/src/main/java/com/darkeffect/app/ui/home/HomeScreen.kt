package com.darkeffect.app.ui.home

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.PickVisualMediaRequest
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkeffect.app.model.Project
import com.darkeffect.app.model.totalDurationMs
import com.darkeffect.app.ui.components.DELogo
import com.darkeffect.app.ui.components.GlassPanel
import com.darkeffect.app.ui.components.NeonButton
import com.darkeffect.app.ui.editor.EditorViewModel
import com.darkeffect.app.ui.theme.DE
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(vm: EditorViewModel, onOpenProject: (String) -> Unit, onSettings: () -> Unit) {
    val scope = rememberCoroutineScope()
    var recents by remember { mutableStateOf<List<Project>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { recents = vm.listProjects() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(50)) { uris ->
        if (uris.isNotEmpty()) {
            busy = true
            scope.launch {
                vm.createProjectFromMedia(uris)
                    .onSuccess { id -> onOpenProject(id) }
                    .onFailure { e -> error = e.message ?: "Import failed." }
                busy = false
            }
        }
    }

    Box(Modifier.fillMaxSize().background(DE.Black)) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp),
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                IconButton(onClick = onSettings) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = DE.TextDim)
                }
            }
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                DELogo(96.dp)
                Spacer(Modifier.height(14.dp))
                Text("DARK EFFECT", fontWeight = FontWeight.Black, fontSize = 22.sp, letterSpacing = 4.sp, color = DE.Text)
                Text("cinematic edits, on your phone", color = DE.TextDim, fontSize = 13.sp)
            }
            Spacer(Modifier.height(24.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                NeonButton(
                    text = "New Project",
                    onClick = { scope.launch { onOpenProject(vm.createEmptyProject()) } },
                    modifier = Modifier.weight(1f).height(52.dp),
                    enabled = !busy,
                )
                NeonButton(
                    text = "Import Video",
                    onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) },
                    modifier = Modifier.weight(1f).height(52.dp),
                    accent = DE.ElectricBlue,
                    enabled = !busy,
                )
            }
            Spacer(Modifier.height(24.dp))
            Text("Recent Projects", color = DE.TextDim, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            if (recents.isEmpty()) {
                Text("Nothing yet. Import something and make it weird.", color = DE.TextDim, fontSize = 13.sp)
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(recents, key = { it.id }) { p ->
                    RecentRow(p) { onOpenProject(p.id) }
                }
            }
        }

        if (busy) {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = DE.NeonPurple)
        }

        error?.let { msg ->
            AlertDialog(
                onDismissRequest = { error = null },
                confirmButton = { TextButton(onClick = { error = null }) { Text("OK", color = DE.NeonPurple) } },
                title = { Text("Heads up", color = DE.Text) },
                text = { Text(msg, color = DE.TextDim) },
                containerColor = DE.Panel,
            )
        }
    }
}

@Composable
private fun RecentRow(p: Project, onClick: () -> Unit) {
    val date = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(p.updatedAt))
    GlassPanel(Modifier.clickable(onClick = onClick)) {
        Text(p.name, color = DE.Text, fontWeight = FontWeight.SemiBold)
        Text(
            "${p.clips.size} clips  -  ${formatShort(p.totalDurationMs())}  -  $date",
            color = DE.TextDim,
            fontSize = 12.sp,
        )
    }
}

private fun formatShort(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}
