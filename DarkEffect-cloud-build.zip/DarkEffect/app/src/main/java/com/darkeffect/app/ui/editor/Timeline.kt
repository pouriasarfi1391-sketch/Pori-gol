package com.darkeffect.app.ui.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkeffect.app.model.Project
import com.darkeffect.app.model.placements
import com.darkeffect.app.model.totalDurationMs
import com.darkeffect.app.ui.theme.DE

private val TRACK_VIDEO_H = 56.dp
private val TRACK_OTHER_H = 34.dp

@Composable
fun Timeline(
    project: Project,
    playhead: Long,
    zoomDp: Float,
    selectedId: String?,
    playing: Boolean,
    onSeek: (Long) -> Unit,
    onSelect: (String?) -> Unit,
    onZoom: (Float) -> Unit,
) {
    val density = LocalDensity.current
    val total = maxOf(project.totalDurationMs(), 10_000L)
    val contentWidth = (total / 1000f * zoomDp).dp + 200.dp
    val pxPerMs = with(density) { zoomDp.dp.toPx() } / 1000f
    val measurer = rememberTextMeasurer()
    val scroll = rememberScrollState()
    val placements = project.placements()
    val latestZoom by rememberUpdatedState(zoomDp)

    // Keep the playhead on screen while playing.
    LaunchedEffect(playhead, playing) {
        if (playing) scroll.scrollTo(maxOf(0, (playhead * pxPerMs).toInt() - 200))
    }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(DE.Panel)
            .border(1.dp, DE.Border, RoundedCornerShape(16.dp))
            .pointerInput(Unit) {
                // Two-finger pinch to zoom. Single-finger gestures are left alone so scrolling still works.
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    var z = latestZoom
                    do {
                        val event = awaitPointerEvent()
                        if (event.changes.count { it.pressed } >= 2) {
                            val factor = event.calculateZoom()
                            if (factor != 1f) {
                                z *= factor
                                onZoom(z)
                            }
                            event.changes.forEach { it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
            .padding(vertical = 6.dp),
    ) {
        Row(Modifier.fillMaxWidth()) {
            // Fixed track labels on the left, the scrollable area on the right.
            Column(Modifier.width(34.dp)) {
                Spacer(Modifier.height(24.dp))
                TrackLabel("VID", TRACK_VIDEO_H)
                TrackLabel("TXT", TRACK_OTHER_H)
                TrackLabel("AUD", TRACK_OTHER_H)
            }
            Box(Modifier.weight(1f).horizontalScroll(scroll)) {
                Box(Modifier.width(contentWidth)) {
                    Column(Modifier.width(contentWidth)) {
                        // Ruler: tap or drag to scrub.
                        Canvas(
                            Modifier
                                .width(contentWidth)
                                .height(24.dp)
                                .pointerInput(zoomDp, total) {
                                    detectDragGestures(
                                        onDragStart = { o -> onSeek((o.x / pxPerMs).toLong()) },
                                        onDrag = { change, _ ->
                                            change.consume()
                                            onSeek((change.position.x / pxPerMs).toLong())
                                        },
                                    )
                                },
                        ) {
                            val pxPerSec = zoomDp.dp.toPx()
                            val step = when {
                                zoomDp >= 120f -> 1
                                zoomDp >= 50f -> 2
                                else -> 5
                            }
                            val seconds = (total / 1000L).toInt() + 10
                            var s = 0
                            while (s <= seconds) {
                                val x = s * pxPerSec
                                drawLine(DE.Border, Offset(x, size.height - 8f), Offset(x, size.height), strokeWidth = 1f)
                                drawText(
                                    measurer,
                                    "%d:%02d".format(s / 60, s % 60),
                                    topLeft = Offset(x + 3f, 2f),
                                    style = TextStyle(color = DE.TextDim, fontSize = 9.sp),
                                )
                                s += step
                            }
                        }

                        // Video track
                        Row(
                            Modifier.width(contentWidth).height(TRACK_VIDEO_H).clickable { onSelect(null) },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            placements.forEach { pl ->
                                val c = pl.clip
                                val w = maxOf(c.durationMs / 1000f * zoomDp, 14f).dp
                                val sel = c.id == selectedId
                                Box(
                                    Modifier
                                        .width(w)
                                        .fillMaxHeight()
                                        .padding(horizontal = 1.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (c.isImage) DE.Panel2 else Color(0xFF1B1530))
                                        .border(
                                            if (sel) 2.dp else 1.dp,
                                            if (sel) DE.NeonPurple else DE.Border,
                                            RoundedCornerShape(8.dp),
                                        )
                                        .clickable { onSelect(c.id) }
                                        .padding(6.dp),
                                ) {
                                    Text(
                                        (if (c.isImage) "IMG  " else "") + c.name,
                                        color = DE.Text,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    c.keyframes.forEach { k ->
                                        Box(
                                            Modifier
                                                .align(Alignment.BottomStart)
                                                .offset(x = k.timeMs / 1000f * zoomDp.dp, y = (-2).dp)
                                                .size(6.dp)
                                                .rotate(45f)
                                                .background(DE.ElectricBlue),
                                        )
                                    }
                                }
                            }
                        }

                        // Text track
                        Box(Modifier.width(contentWidth).height(TRACK_OTHER_H)) {
                            project.texts.forEach { t ->
                                Box(
                                    Modifier
                                        .offset(x = t.startMs / 1000f * zoomDp.dp)
                                        .width(maxOf(t.durationMs / 1000f * zoomDp, 24f).dp)
                                        .fillMaxHeight()
                                        .padding(2.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(DE.NeonPurple.copy(alpha = 0.35f))
                                        .padding(horizontal = 6.dp),
                                    contentAlignment = Alignment.CenterStart,
                                ) {
                                    Text(t.text, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }

                        // Audio track
                        Box(Modifier.width(contentWidth).height(TRACK_OTHER_H)) {
                            project.audio.forEach { a ->
                                Box(
                                    Modifier
                                        .offset(x = a.startMs / 1000f * zoomDp.dp)
                                        .width(maxOf(a.durationMs / 1000f * zoomDp, 24f).dp)
                                        .fillMaxHeight()
                                        .padding(2.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(DE.ElectricBlue.copy(alpha = 0.22f))
                                        .padding(horizontal = 6.dp),
                                    contentAlignment = Alignment.CenterStart,
                                ) {
                                    Text(a.name, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }

                    // Playhead line across all tracks.
                    Box(
                        Modifier
                            .matchParentSize()
                            .offset(x = (playhead * pxPerMs / density.density).dp)
                            .width(2.dp)
                            .background(DE.ElectricBlue),
                    )
                }
            }
        }
    }
}

@Composable
private fun TrackLabel(text: String, h: androidx.compose.ui.unit.Dp) {
    Box(Modifier.height(h).width(34.dp), contentAlignment = Alignment.Center) {
        Text(text, color = DE.TextDim, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}
