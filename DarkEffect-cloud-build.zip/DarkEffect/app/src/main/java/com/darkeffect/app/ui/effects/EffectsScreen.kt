package com.darkeffect.app.ui.effects

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkeffect.app.model.Adjust
import com.darkeffect.app.model.ClipEffect
import com.darkeffect.app.model.EffectType
import com.darkeffect.app.ui.components.GlassPanel
import com.darkeffect.app.ui.components.NeonButton
import com.darkeffect.app.ui.components.TopBar
import com.darkeffect.app.ui.editor.EditorViewModel
import com.darkeffect.app.ui.theme.DE

private val presets = listOf(
    "Cinema" to Adjust(brightness = -0.05f, contrast = 0.2f, saturation = -0.1f),
    "Punchy" to Adjust(contrast = 0.3f, saturation = 0.25f),
    "Faded" to Adjust(brightness = 0.1f, contrast = -0.2f, saturation = -0.3f),
    "Reset" to Adjust(),
)

@Composable
fun EffectsScreen(vm: EditorViewModel, onBack: () -> Unit) {
    val project by vm.project.collectAsState()
    val selectedId by vm.selectedClipId.collectAsState()
    val clip = project?.clips?.firstOrNull { it.id == selectedId }

    Column(
        Modifier.fillMaxSize().background(DE.Black).statusBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        TopBar(clip?.let { "Effects  -  ${it.name}" } ?: "Effects", onBack)

        if (clip == null) {
            Text("Select a clip in the editor first.", color = DE.TextDim)
            return
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                GlassPanel {
                    Text("Preset Effects", color = DE.Text, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        presets.forEach { (name, adj) ->
                            NeonButton(
                                name,
                                onClick = { vm.setAdjust(clip.id, adj) },
                                modifier = Modifier.weight(1f),
                                accent = DE.ElectricBlue,
                            )
                        }
                    }
                }
            }
            EffectType.entries.groupBy { it.category }.forEach { (category, types) ->
                item {
                    Text(category.title, color = DE.TextDim, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
                items(types) { type ->
                    EffectRow(
                        type = type,
                        applied = clip.effects.firstOrNull { it.type == type },
                        onToggle = { vm.toggleEffect(clip.id, type) },
                        onAmount = { vm.setEffectAmount(clip.id, type, it) },
                    )
                }
            }
        }
    }
}

@Composable
private fun EffectRow(
    type: EffectType,
    applied: ClipEffect?,
    onToggle: () -> Unit,
    onAmount: (Float) -> Unit,
) {
    GlassPanel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(type.label, color = DE.Text, fontWeight = FontWeight.SemiBold)
                Text(
                    if (type.implemented) "Renders on export" else "Coming soon: saved, not rendered yet",
                    color = DE.TextDim,
                    fontSize = 11.sp,
                )
            }
            Switch(checked = applied != null, onCheckedChange = { onToggle() })
        }
        if (applied != null) {
            var local by remember(applied.amount) { mutableFloatStateOf(applied.amount) }
            Slider(
                value = local,
                onValueChange = { local = it },
                onValueChangeFinished = { onAmount(local) },
                valueRange = 0f..1f,
            )
        }
    }
}
