package com.darkeffect.app.engine

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.darkeffect.app.model.Project
import java.io.File

class ExportEngine(private val context: Context) {

    private var transformer: Transformer? = null
    private val holder = ProgressHolder()

    fun start(project: Project, height: Int, fps: Int, out: File, onSuccess: () -> Unit, onFail: (String) -> Unit) {
        val composition = ExportPlan.build(project, height, fps)
        val t = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, result: ExportResult) {
                    transformer = null
                    onSuccess()
                }

                override fun onError(composition: Composition, result: ExportResult, exception: ExportException) {
                    transformer = null
                    onFail("Export failed. Try 720p, or check that the clips are still there.")
                }
            })
            .build()
        transformer = t
        try {
            t.start(composition, out.absolutePath)
        } catch (e: Exception) {
            transformer = null
            onFail("Export couldn't start. Try again or lower the resolution.")
        }
    }

    /** Call on the main thread. Returns 0..1. */
    fun progress(): Float {
        val t = transformer ?: return 0f
        t.getProgress(holder)
        return holder.progress / 100f
    }

    fun cancel() {
        transformer?.cancel()
        transformer = null
    }
}

object GallerySaver {
    fun save(context: Context, src: File, displayName: String): Uri? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/DARK EFFECT")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
            context.contentResolver.openOutputStream(uri)?.use { out ->
                src.inputStream().use { it.copyTo(out, 1 shl 16) }
            } ?: return null
            val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            context.contentResolver.update(uri, done, null, null)
            uri
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "DARK EFFECT")
            dir.mkdirs()
            val dest = File(dir, displayName)
            src.copyTo(dest, overwrite = true)
            MediaScannerConnection.scanFile(context, arrayOf(dest.absolutePath), arrayOf("video/mp4"), null)
            Uri.fromFile(dest)
        }
    }
}
