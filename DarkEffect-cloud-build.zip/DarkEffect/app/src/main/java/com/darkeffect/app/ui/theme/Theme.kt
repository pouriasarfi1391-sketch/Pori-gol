package com.darkeffect.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object DE {
    val Black = Color(0xFF000000)
    val Surface = Color(0xFF0D0D10)
    val Panel = Color(0xFF16161B)
    val Panel2 = Color(0xFF1F1F26)
    val Border = Color(0xFF2A2A33)
    val NeonPurple = Color(0xFFB026FF)
    val ElectricBlue = Color(0xFF00E5FF)
    val Text = Color(0xFFEDEDF2)
    val TextDim = Color(0xFF8A8A99)
    val Red = Color(0xFFFF3D6E)
}

private val DarkEffectScheme = darkColorScheme(
    primary = DE.NeonPurple,
    onPrimary = Color.White,
    secondary = DE.ElectricBlue,
    background = DE.Black,
    onBackground = DE.Text,
    surface = DE.Surface,
    onSurface = DE.Text,
    surfaceVariant = DE.Panel,
    error = DE.Red,
)

@Composable
fun DarkEffectTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkEffectScheme, typography = Typography(), content = content)
}
