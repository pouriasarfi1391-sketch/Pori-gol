package com.darkeffect.app.ui.export

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkeffect.app.engine.ExportEngine
import com.darkeffect.app.engine.GallerySaver
import com.darkeffect.app.model.formatTimecode
import com.darkeffect.app.model.totalDurationMs
import com.darkeffect.app.ui.components.GlassPanel
import com.darkeffect.app.ui.components.NeonButton
import com.darkeffect.app.ui.components.TopBar
import com.darkeffect.app.ui.editor.EditorViewModel
import com.darkeffect.app.ui.theme.DE
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun ExportScreen(vm: EditorViewModel, onBack: () -> Unit) {
    val project by vm.project.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember { ExportEngine(context) }

    var height by remember { mutableIntStateOf(1080) }
    var fps by remember { mutableIntStateOf(30) }
    var toGallery by remember { mutableStateOf(true) }
    var running by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var status by remember { mutableStateOf("Pick a resolution and go.") }

    DisposableEffect(Unit) { onDispose { engine.cancel() } }
    LaunchedEffect(running) {
        while (running) {
            progress = engine.progress()
            delay(200)
        }
    }

    val p = project

    Column(
        Modifier.fillMaxSize().background(DE.Black).statusBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        TopBar("Export", onBack)

        GlassPanel {
            Text("Resolution", color = DE.Text, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(720 to "720p", 1080 to "1080p").forEach { (h, label) ->
                    FilterChip(
                        selected = height == h,
                        onClick = { if (!running) height = h },
                        label = { Text(label) },
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            Text("Frame rate", color = DE.Text, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(24, 30, 60).forEach { f ->
                    FilterChip(
                        selected = fps == f,
                        onClick = { if (!running) fps = f },
                        label = { Text("$f fps") },
                    )
                }
            }
        }

        GlassPanel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Save to Gallery", color = DE.Text, fontWeight = FontWeight.SemiBold)
                    Text("Movies/DARK EFFECT", color = DE.TextDim, fontSize = 12.sp)
                }
                Switch(checked = toGallery, onCheckedChange = { toGallery = it })
            }
        }

        GlassPanel {
            val length = p?.totalDurationMs() ?: 0L
            Text(
                "${p?.clips?.size ?: 0} clips  -  ${formatTimecode(length)} total",
                color = DE.TextDim,
                fontSize = 12.sp,
            )
            Text(status, color = DE.Text)
            if (running || progress > 0f) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth(),
                    color = DE.NeonPurple,
                    trackColor = DE.Panel2,
                )
            }
            NeonButton(
                text = if (running) "Rendering..." else "Export",
                onClick = {
                    val proj = project
                    if (proj != null && proj.clips.isNotEmpty()) {
                        val out = File(context.cacheDir, "dark_effect_${System.currentTimeMillis()}.mp4")
                        val name = "DARK_EFFECT_${System.currentTimeMillis()}.mp4"
                        running = true
                        progress = 0f
                        status = "Rendering ${height}p at $fps fps..."
                        engine.start(
                            project = proj,
                            height = height,
                            fps = fps,
                            out = out,
                            onSuccess = {
                                running = false
                                progress = 1f
                                if (toGallery) {
                                    scope.launch {
                                        val uri = withContext(Dispatchers.IO) {
                                            runCatching { GallerySaver.save(context, out, name) }.getOrNull()
                                        }
                                        status = if (uri != null) {
                                            "Saved to Movies/DARK EFFECT."
                                        } else {
                                            "Rendered, but couldn't save to Gallery. Check storage permission."
                                        }
                                    }
                                } else {
                                    status = "Export complete. File is in app cache."
                                }
                            },
                            onFail = { msg ->
                                running = false
                                status = msg
                            },
                        )
                    } else {
                        status = "Add some clips first."
                    }
                },
                enabled = !running && p != null && p.clips.isNotEmpty(),
                modifier = Modifier.fillMaxWidth().height(52.dp),
            )
            if (running) {
                NeonButton(
                    "Cancel",
                    onClick = {
                        engine.cancel()
                        running = false
                        status = "Export cancelled."
                    },
                    accent = DE.Red,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}
