package com.darkeffect.app.data

import android.content.Context
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import com.darkeffect.app.model.AudioLayer
import com.darkeffect.app.model.Clip
import java.io.File
import java.util.UUID

/** Copies picked media into app storage so projects keep working after the source changes. */
class MediaImporter(private val context: Context) {

    companion object {
        const val IMAGE_DEFAULT_MS = 5000L
    }

    private val mediaDir = File(context.filesDir, "media").apply { mkdirs() }

    fun importClip(uri: Uri): Clip {
        val mime = context.contentResolver.getType(uri) ?: ""
        val isImage = mime.startsWith("image/")
        val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: if (isImage) "jpg" else "mp4"
        val dest = File(mediaDir, "${UUID.randomUUID()}.$ext")
        copy(uri, dest)

        return if (isImage) {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(dest.path, opts)
            Clip(
                uri = Uri.fromFile(dest).toString(),
                name = displayName(uri),
                isImage = true,
                sourceDurationMs = IMAGE_DEFAULT_MS,
                srcWidth = opts.outWidth.coerceAtLeast(1),
                srcHeight = opts.outHeight.coerceAtLeast(1),
            )
        } else {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(dest.path)
                val duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                require(duration > 0L) { "No playable video track" }
                var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1920
                var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1080
                val rotation = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                if (rotation == 90 || rotation == 270) { val t = w; w = h; h = t }
                Clip(
                    uri = Uri.fromFile(dest).toString(),
                    name = displayName(uri),
                    isImage = false,
                    sourceDurationMs = duration,
                    srcWidth = w,
                    srcHeight = h,
                )
            } finally {
                r.release()
            }
        }
    }

    fun importAudio(uri: Uri): AudioLayer {
        val name = displayName(uri)
        val ext = name.substringAfterLast('.', "m4a")
        val dest = File(mediaDir, "${UUID.randomUUID()}.$ext")
        copy(uri, dest)
        val r = MediaMetadataRetriever()
        val duration = try {
            r.setDataSource(dest.path)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally {
            r.release()
        }
        require(duration > 0L) { "No audio track" }
        return AudioLayer(uri = Uri.fromFile(dest).toString(), name = name, durationMs = duration)
    }

    private fun copy(uri: Uri, dest: File) {
        val input = context.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Can't open file")
        input.use { src -> dest.outputStream().use { out -> src.copyTo(out, 1 shl 16) } }
    }

    private fun displayName(uri: Uri): String =
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: "Clip"
}
