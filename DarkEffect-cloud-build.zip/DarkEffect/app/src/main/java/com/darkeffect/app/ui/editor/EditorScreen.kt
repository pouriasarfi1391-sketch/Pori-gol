package com.darkeffect.app.ui.editor

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.PickVisualMediaRequest
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.darkeffect.app.model.Adjust
import com.darkeffect.app.model.Clip
import com.darkeffect.app.model.KEY_PROPS
import com.darkeffect.app.model.Project
import com.darkeffect.app.model.formatTimecode
import com.darkeffect.app.model.placementAt
import com.darkeffect.app.model.totalDurationMs
import com.darkeffect.app.ui.components.GlassPanel
import com.darkeffect.app.ui.components.NeonButton
import com.darkeffect.app.ui.components.TopBar
import com.darkeffect.app.ui.theme.DE
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.darkeffect.app.model.placements

@Composable
fun EditorScreen(
    vm: EditorViewModel,
    projectId: String,
    onBack: () -> Unit,
    onEffects: () -> Unit,
    onExport: () -> Unit,
) {
    val project by vm.project.collectAsState()
    val playhead by vm.playhead.collectAsState()
    val playing by vm.isPlaying.collectAsState()
    val selectedId by vm.selectedClipId.collectAsState()
    val zoom by vm.zoomDp.collectAsState()
    val canUndo by vm.canUndo.collectAsState()
    val canRedo by vm.canRedo.collectAsState()
    val snack = remember { SnackbarHostState() }
    var tab by remember { mutableIntStateOf(0) }

    val addMedia = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(50)) { uris ->
        if (uris.isNotEmpty()) vm.appendMedia(uris)
    }
    val addAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { vm.addAudio(it) }
    }

    LaunchedEffect(projectId) {
        if (vm.project.value?.id != projectId) vm.open(projectId)
    }
    LaunchedEffect(Unit) {
        vm.message.collect { snack.showSnackbar(it) }
    }

    val p = project
    if (p == null) {
        Box(Modifier.fillMaxSize().background(DE.Black), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = DE.NeonPurple)
        }
        return
    }

    val current = p.placementAt(playhead)
    val selected = p.clips.firstOrNull { it.id == selectedId }

    Box(Modifier.fillMaxSize().background(DE.Black)) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            // Top bar
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = DE.Text) }
                Text(
                    p.name,
                    color = DE.Text,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = { vm.undo() }, enabled = canUndo) {
                    Icon(Icons.Default.Undo, contentDescription = "Undo", tint = if (canUndo) DE.Text else DE.TextDim)
                }
                IconButton(onClick = { vm.redo() }, enabled = canRedo) {
                    Icon(Icons.Default.Redo, contentDescription = "Redo", tint = if (canRedo) DE.Text else DE.TextDim)
                }
                NeonButton("Export", onClick = onExport, modifier = Modifier.height(40.dp), accent = DE.ElectricBlue)
            }

            // Preview
            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color.Black)
                    .border(1.dp, Brush.linearGradient(listOf(DE.NeonPurple, DE.ElectricBlue)), RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center,
            ) {
                val cur = current?.clip
                when {
                    cur == null -> Text("Import clips to start", color = DE.TextDim)
                    cur.isImage -> StillPreview(cur.uri)
                    else -> AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply {
                                useController = false
                                player = vm.player
                                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                            }
                        },
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }

            // Transport
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.togglePlay() }) {
                    Icon(
                        if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (playing) "Pause" else "Play",
                        tint = DE.NeonPurple,
                    )
                }
                Text(
                    "${formatTimecode(playhead)} / ${formatTimecode(p.totalDurationMs())}",
                    color = DE.Text,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                )
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { vm.zoomBy(0.8f) }) { Text("-", color = DE.Text, fontSize = 20.sp) }
                IconButton(onClick = { vm.zoomBy(1.25f) }) { Text("+", color = DE.Text, fontSize = 20.sp) }
            }

            // Toolbar
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ToolButton("Add media") { addMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) }
                ToolButton("Split") { vm.splitAtPlayhead() }
                ToolButton("Delete", enabled = selected != null, accent = DE.Red) { selected?.let { vm.deleteClip(it.id) } }
                ToolButton("Move left", enabled = selected != null) { vm.moveSelected(-1) }
                ToolButton("Move right", enabled = selected != null) { vm.moveSelected(1) }
                ToolButton("Effects", enabled = selected != null, accent = DE.NeonPurple) { onEffects() }
                ToolButton("Text") { vm.addText() }
                ToolButton("Audio", accent = DE.ElectricBlue) { addAudio.launch(arrayOf("audio/*")) }
            }

            // Timeline
            Timeline(
                project = p,
                playhead = playhead,
                zoomDp = zoom,
                selectedId = selectedId,
                playing = playing,
                onSeek = { vm.seekTo(it) },
                onSelect = { vm.selectClip(it) },
                onZoom = { vm.setZoom(it) },
            )

            // Bottom panel
            TabRow(
                selectedTabIndex = tab,
                containerColor = Color.Transparent,
                contentColor = DE.NeonPurple,
            ) {
                listOf("Clip", "Keyframes", "Layers").forEachIndexed { i, label ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(label) })
                }
            }
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
                when (tab) {
                    0 -> ClipPanel(vm, selected)
                    1 -> KeyframePanel(vm, p, selected, playhead)
                    else -> LayersPanel(vm, p) { addAudio.launch(arrayOf("audio/*")) }
                }
            }
        }

        SnackbarHost(snack, Modifier.align(Alignment.BottomCenter).padding(bottom = 90.dp))
    }
}

@Composable
private fun StillPreview(uri: String) {
    val bmp by produceState<ImageBitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            Uri.parse(uri).path?.let { path ->
                BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = 2 })
            }?.asImageBitmap()
        }
    }
    bmp?.let { Image(it, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
}

@Composable
private fun ToolButton(
    text: String,
    enabled: Boolean = true,
    accent: Color = DE.ElectricBlue,
    onClick: () -> Unit,
) {
    NeonButton(text, onClick = onClick, modifier = Modifier.height(36.dp), accent = accent, enabled = enabled)
}

@Composable
private fun ClipPanel(vm: EditorViewModel, selected: Clip?) {
    if (selected == null) {
        Text("Tap a clip on the timeline to trim, crop, or grade it.", color = DE.TextDim, modifier = Modifier.padding(16.dp))
        return
    }
    Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        GlassPanel {
            Text("Trim  ${formatTimecode(selected.inMs)} - ${formatTimecode(selected.outMs)}", color = DE.Text, fontWeight = FontWeight.SemiBold)
            var range by remember(selected.id, selected.inMs, selected.outMs) {
                mutableStateOf(selected.inMs.toFloat()..selected.outMs.toFloat())
            }
            RangeSlider(
                value = range,
                onValueChange = { range = it },
                valueRange = 0f..selected.sourceDurationMs.toFloat(),
                onValueChangeFinished = { vm.trimClip(selected.id, range.start.toLong(), range.endInclusive.toLong()) },
            )
        }

        GlassPanel {
            Text("Crop", color = DE.Text, fontWeight = FontWeight.SemiBold)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("original", "16:9", "9:16", "1:1", "4:5").forEach { r ->
                    FilterChip(
                        selected = selected.crop == r,
                        onClick = { vm.setCrop(selected.id, r) },
                        label = { Text(r) },
                    )
                }
            }
        }

        GlassPanel {
            Text("Color", color = DE.Text, fontWeight = FontWeight.SemiBold)
            val a = selected.adjust
            AdjustSlider("Brightness", a.brightness) { v -> vm.setAdjust(selected.id, a.copy(brightness = v)) }
            AdjustSlider("Contrast", a.contrast) { v -> vm.setAdjust(selected.id, a.copy(contrast = v)) }
            AdjustSlider("Saturation", a.saturation) { v -> vm.setAdjust(selected.id, a.copy(saturation = v)) }
            AdjustSlider("Exposure", a.exposure) { v -> vm.setAdjust(selected.id, a.copy(exposure = v)) }
        }
    }
}

@Composable
private fun AdjustSlider(label: String, value: Float, onCommit: (Float) -> Unit) {
    var local by remember(value) { mutableFloatStateOf(value) }
    Column {
        Row {
            Text(label, color = DE.TextDim, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text("%+.2f".format(local), color = DE.TextDim, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        }
        Slider(
            value = local,
            onValueChange = { local = it },
            onValueChangeFinished = { onCommit(local) },
            valueRange = -1f..1f,
        )
    }
}

@Composable
private fun KeyframePanel(vm: EditorViewModel, project: Project, selected: Clip?, playhead: Long) {
    if (selected == null) {
        Text("Select a clip, then move the playhead over it to set keyframes.", color = DE.TextDim, modifier = Modifier.padding(16.dp))
        return
    }
    var prop by remember { mutableStateOf(KEY_PROPS.first()) }
    var value by remember(prop.key) { mutableFloatStateOf(prop.default) }
    val offset = playhead - (project.placementAt(playhead)?.startMs ?: 0L)
    val inside = project.placementAt(playhead)?.clip?.id == selected.id

    Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        GlassPanel {
            Text("Keyframe at playhead", color = DE.Text, fontWeight = FontWeight.SemiBold)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                KEY_PROPS.forEach { kp ->
                    FilterChip(selected = prop.key == kp.key, onClick = { prop = kp }, label = { Text(kp.label) })
                }
            }
            Slider(value = value, onValueChange = { value = it }, valueRange = prop.min..prop.max)
            Text(
                "%.2f at %s into clip".format(value, formatTimecode(offset.coerceAtLeast(0L))),
                color = DE.TextDim,
                fontSize = 12.sp,
            )
            NeonButton(
                "Add keyframe",
                onClick = { vm.addKeyframe(selected.id, prop.key, value) },
                enabled = inside,
            )
        }
        GlassPanel {
            Text("Markers on this clip", color = DE.Text, fontWeight = FontWeight.SemiBold)
            if (selected.keyframes.isEmpty()) {
                Text("None yet.", color = DE.TextDim, fontSize = 12.sp)
            }
            selected.keyframes.sortedBy { it.timeMs }.forEach { k ->
                val label = KEY_PROPS.firstOrNull { it.key == k.property }?.label ?: k.property
                Text("${formatTimecode(k.timeMs)}  $label  %.2f".format(k.value), color = DE.TextDim, fontSize = 12.sp)
            }
            Text(
                "Keyframes are saved and shown on the timeline. Animation on export is not wired up yet.",
                color = DE.TextDim,
                fontSize = 11.sp,
            )
        }
    }
}

@Composable
private fun LayersPanel(vm: EditorViewModel, project: Project, onPickAudio: () -> Unit) {
    Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        GlassPanel {
            Text("Text layers", color = DE.Text, fontWeight = FontWeight.SemiBold)
            NeonButton("Add text at playhead", onClick = { vm.addText() })
            project.texts.forEach { t ->
                Text("${formatTimecode(t.startMs)}  ${t.text}", color = DE.TextDim, fontSize = 12.sp)
            }
        }
        GlassPanel {
            Text("Audio layers", color = DE.Text, fontWeight = FontWeight.SemiBold)
            NeonButton("Add audio at playhead", onClick = onPickAudio, accent = DE.ElectricBlue)
            project.audio.forEach { a ->
                Text("${formatTimecode(a.startMs)}  ${a.name}", color = DE.TextDim, fontSize = 12.sp)
            }
        }
        Text(
            "Text and audio layers show on the timeline. Mixing them into the export is still in progress.",
            color = DE.TextDim,
            fontSize = 11.sp,
        )
    }
}
