package com.darkeffect.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkeffect.app.ui.theme.DE

@Composable
fun DELogo(size: Dp = 96.dp) {
    Box(
        Modifier
            .size(size)
            .border(1.5.dp, Brush.linearGradient(listOf(DE.NeonPurple, DE.ElectricBlue)), CircleShape)
            .background(DE.Panel, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            "DE",
            fontSize = (size.value * 0.36f).sp,
            fontWeight = FontWeight.Black,
            color = Color.White,
            style = TextStyle(shadow = Shadow(color = DE.NeonPurple, offset = Offset.Zero, blurRadius = 36f)),
        )
    }
}

@Composable
fun NeonButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    accent: Color = DE.NeonPurple,
    enabled: Boolean = true,
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.border(
            1.dp,
            accent.copy(alpha = if (enabled) 0.9f else 0.2f),
            RoundedCornerShape(14.dp),
        ),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = accent.copy(alpha = 0.18f),
            contentColor = Color.White,
            disabledContainerColor = DE.Panel,
            disabledContentColor = DE.TextDim,
        ),
    ) {
        Text(text, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun GlassPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(DE.Panel)
            .border(1.dp, DE.Border, RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
        content = content,
    )
}

@Composable
fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = DE.Text)
        }
        Text(title, color = DE.Text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}
