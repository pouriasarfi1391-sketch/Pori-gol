package com.darkeffect.app.data

import android.content.Context
import com.darkeffect.app.model.Project
import kotlinx.serialization.json.Json
import java.io.File

class ProjectStore(context: Context) {
    private val dir = File(context.filesDir, "projects").apply { mkdirs() }
    private val json = Json { prettyPrint = false; ignoreUnknownKeys = true; encodeDefaults = true }

    fun save(project: Project) {
        val tmp = File(dir, "${project.id}.json.tmp")
        tmp.writeText(json.encodeToString(Project.serializer(), project))
        val dest = File(dir, "${project.id}.json")
        if (!tmp.renameTo(dest)) {
            dest.writeText(tmp.readText())
            tmp.delete()
        }
    }

    fun load(id: String): Project? = runCatching {
        json.decodeFromString(Project.serializer(), File(dir, "$id.json").readText())
    }.getOrNull()

    fun list(): List<Project> = dir.listFiles { f -> f.name.endsWith(".json") }
        ?.mapNotNull { f -> runCatching { json.decodeFromString(Project.serializer(), f.readText()) }.getOrNull() }
        ?.sortedByDescending { it.updatedAt }
        ?: emptyList()
}
