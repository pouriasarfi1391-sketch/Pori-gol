package com.darkeffect.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.darkeffect.app.ui.editor.EditorScreen
import com.darkeffect.app.ui.editor.EditorViewModel
import com.darkeffect.app.ui.effects.EffectsScreen
import com.darkeffect.app.ui.export.ExportScreen
import com.darkeffect.app.ui.home.HomeScreen
import com.darkeffect.app.ui.settings.SettingsScreen
import com.darkeffect.app.ui.theme.DE
import com.darkeffect.app.ui.theme.DarkEffectTheme

class MainActivity : ComponentActivity() {

    private val editor: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DarkEffectTheme {
                val nav = rememberNavController()
                NavHost(
                    navController = nav,
                    startDestination = "home",
                    modifier = Modifier.fillMaxSize().background(DE.Black),
                ) {
                    composable("home") {
                        HomeScreen(
                            vm = editor,
                            onOpenProject = { id -> nav.navigate("editor/$id") },
                            onSettings = { nav.navigate("settings") },
                        )
                    }
                    composable(
                        "editor/{projectId}",
                        arguments = listOf(navArgument("projectId") { type = NavType.StringType }),
                    ) { entry ->
                        val id = entry.arguments?.getString("projectId") ?: return@composable
                        EditorScreen(
                            vm = editor,
                            projectId = id,
                            onBack = { nav.popBackStack() },
                            onEffects = { nav.navigate("effects") },
                            onExport = { nav.navigate("export") },
                        )
                    }
                    composable("effects") {
                        EffectsScreen(vm = editor, onBack = { nav.popBackStack() })
                    }
                    composable("export") {
                        ExportScreen(vm = editor, onBack = { nav.popBackStack() })
                    }
                    composable("settings") {
                        SettingsScreen(onBack = { nav.popBackStack() })
                    }
                }
            }
        }
    }
}
