package com.darkeffect.app.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkeffect.app.ui.components.GlassPanel
import com.darkeffect.app.ui.components.TopBar
import com.darkeffect.app.ui.theme.DE

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(DE.Black).statusBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        TopBar("Settings", onBack)
        GlassPanel {
            Text("DARK EFFECT 0.1.0", color = DE.Text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(
                "Imported media is copied into the app's private storage, so projects open later even if the original file moves.",
                color = DE.TextDim,
                fontSize = 13.sp,
            )
            Text(
                "Exports save to Movies/DARK EFFECT on Android 10 and newer.",
                color = DE.TextDim,
                fontSize = 13.sp,
            )
        }
    }
}
