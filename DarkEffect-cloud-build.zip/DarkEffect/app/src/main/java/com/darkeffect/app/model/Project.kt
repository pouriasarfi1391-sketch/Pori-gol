package com.darkeffect.app.model

import kotlinx.serialization.Serializable
import java.util.UUID

enum class EffectCategory(val title: String) {
    GLITCH("Glitch Effects"),
    NEON_GLOW("Neon Glow"),
    CINEMATIC_BLUR("Cinematic Blur"),
    RGB_SPLIT("RGB Split"),
    VELOCITY("Velocity Effects"),
    SHAKE("Shake Effects"),
    COLOR_GRADING("Color Grading"),
}

/** implemented = rendered on export. Others are stored on the clip and shown as "coming soon". */
enum class EffectType(val label: String, val category: EffectCategory, val implemented: Boolean) {
    GLITCH("Glitch", EffectCategory.GLITCH, false),
    NEON_GLOW("Neon Glow", EffectCategory.NEON_GLOW, false),
    CINEMATIC_BLUR("Cinematic Blur", EffectCategory.CINEMATIC_BLUR, false),
    RGB_SPLIT("RGB Split", EffectCategory.RGB_SPLIT, false),
    VELOCITY("Velocity Ramp", EffectCategory.VELOCITY, false),
    SHAKE("Shake", EffectCategory.SHAKE, false),
    VHS("VHS", EffectCategory.SHAKE, false),
    TEAL_ORANGE("Teal & Orange", EffectCategory.COLOR_GRADING, true),
    NOIR("Noir", EffectCategory.COLOR_GRADING, true),
    WARM_CINEMA("Warm Cinema", EffectCategory.COLOR_GRADING, true),
}

@Serializable
data class Adjust(
    val brightness: Float = 0f,
    val contrast: Float = 0f,
    val saturation: Float = 0f,
    val exposure: Float = 0f,
)

@Serializable
data class ClipEffect(val type: EffectType, val amount: Float = 0.6f)

@Serializable
data class Keyframe(val timeMs: Long, val property: String, val value: Float)

@Serializable
data class Clip(
    val id: String = UUID.randomUUID().toString(),
    val uri: String,
    val name: String,
    val isImage: Boolean = false,
    val sourceDurationMs: Long,
    val inMs: Long = 0L,
    val outMs: Long = sourceDurationMs,
    val srcWidth: Int = 1920,
    val srcHeight: Int = 1080,
    val crop: String = "original",
    val adjust: Adjust = Adjust(),
    val effects: List<ClipEffect> = emptyList(),
    val keyframes: List<Keyframe> = emptyList(),
) {
    val durationMs: Long get() = outMs - inMs
}

@Serializable
data class TextLayer(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val startMs: Long,
    val durationMs: Long,
)

@Serializable
data class AudioLayer(
    val id: String = UUID.randomUUID().toString(),
    val uri: String,
    val name: String,
    val startMs: Long = 0L,
    val durationMs: Long,
)

@Serializable
data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val clips: List<Clip> = emptyList(),
    val texts: List<TextLayer> = emptyList(),
    val audio: List<AudioLayer> = emptyList(),
)

data class Placement(val clip: Clip, val startMs: Long, val index: Int)

fun Project.totalDurationMs(): Long = clips.sumOf { it.durationMs }

fun Project.videoClips(): List<Clip> = clips.filter { !it.isImage }

fun Project.placements(): List<Placement> {
    var t = 0L
    return clips.mapIndexed { i, c -> Placement(c, t, i).also { t += c.durationMs } }
}

fun Project.placementAt(ms: Long): Placement? =
    placements().firstOrNull { ms >= it.startMs && ms < it.startMs + it.clip.durationMs }

data class KeyProp(val key: String, val label: String, val min: Float, val max: Float, val default: Float)

val KEY_PROPS = listOf(
    KeyProp("position_x", "Position X", -1f, 1f, 0f),
    KeyProp("position_y", "Position Y", -1f, 1f, 0f),
    KeyProp("scale", "Scale", 0f, 3f, 1f),
    KeyProp("rotation", "Rotation", -180f, 180f, 0f),
    KeyProp("opacity", "Opacity", 0f, 1f, 1f),
)

fun formatTimecode(ms: Long): String {
    val safe = ms.coerceAtLeast(0L)
    val s = safe / 1000
    val tenth = (safe % 1000) / 100
    return "%02d:%02d.%d".format(s / 60, s % 60, tenth)
}
