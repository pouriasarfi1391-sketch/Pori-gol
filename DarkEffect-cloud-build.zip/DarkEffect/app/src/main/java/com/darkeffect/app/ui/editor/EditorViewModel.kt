package com.darkeffect.app.ui.editor

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.darkeffect.app.data.MediaImporter
import com.darkeffect.app.data.ProjectStore
import com.darkeffect.app.model.Adjust
import com.darkeffect.app.model.AudioLayer
import com.darkeffect.app.model.Clip
import com.darkeffect.app.model.ClipEffect
import com.darkeffect.app.model.EffectType
import com.darkeffect.app.model.Keyframe
import com.darkeffect.app.model.Project
import com.darkeffect.app.model.TextLayer
import com.darkeffect.app.model.placementAt
import com.darkeffect.app.model.totalDurationMs
import com.darkeffect.app.model.videoClips
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    companion object {
        const val MIN_CLIP_MS = 100L
        const val TEXT_DEFAULT_MS = 3000L
    }

    private val store = ProjectStore(app)
    private val importer = MediaImporter(app)

    val player: ExoPlayer = ExoPlayer.Builder(app).build()

    private val _project = MutableStateFlow<Project?>(null)
    val project: StateFlow<Project?> = _project.asStateFlow()
    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()
    private val _canRedo = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()

    val playhead = MutableStateFlow(0L)
    val isPlaying = MutableStateFlow(false)
    val selectedClipId = MutableStateFlow<String?>(null)
    val zoomDp = MutableStateFlow(60f)

    private val _message = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val message: SharedFlow<String> = _message.asSharedFlow()

    private val undoStack = ArrayDeque<Project>()
    private val redoStack = ArrayDeque<Project>()
    private var playlistSignature = ""
    private var lastClipId: String? = null
    private var ticker: Job? = null
    private var saveJob: Job? = null

    init {
        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                pause()
                _message.tryEmit("This clip can't be played. It may be an unsupported format.")
            }
        })
    }

    // ---------- Projects ----------

    suspend fun listProjects(): List<Project> = withContext(Dispatchers.IO) { store.list() }

    suspend fun createEmptyProject(): String = withContext(Dispatchers.IO) {
        Project(name = "Untitled project").also { store.save(it) }.id
    }

    suspend fun createProjectFromMedia(uris: List<Uri>): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val clips = uris.mapNotNull { uri -> runCatching { importer.importClip(uri) }.getOrNull() }
            check(clips.isNotEmpty()) { "Couldn't read those files. Try a different video." }
            Project(name = "New edit", clips = clips).also { store.save(it) }.id
        }
    }

    suspend fun open(id: String) {
        val p = withContext(Dispatchers.IO) { store.load(id) } ?: return
        pause()
        undoStack.clear()
        redoStack.clear()
        refreshFlags()
        playhead.value = 0L
        selectedClipId.value = null
        _project.value = p
        rebuildPlaylist(force = true)
    }

    fun appendMedia(uris: List<Uri>) {
        viewModelScope.launch {
            val clips = withContext(Dispatchers.IO) {
                uris.mapNotNull { uri -> runCatching { importer.importClip(uri) }.getOrNull() }
            }
            if (clips.isEmpty()) {
                _message.tryEmit("Couldn't read those files.")
            } else {
                commit { p -> p.copy(clips = p.clips + clips) }
            }
        }
    }

    fun addAudio(uri: Uri) {
        viewModelScope.launch {
            val layer = withContext(Dispatchers.IO) { runCatching { importer.importAudio(uri) }.getOrNull() }
            if (layer == null) {
                _message.tryEmit("Couldn't read that audio file.")
            } else {
                commit { p -> p.copy(audio = p.audio + layer.copy(startMs = playhead.value)) }
            }
        }
    }

    // ---------- History ----------

    private fun commit(change: (Project) -> Project) {
        val current = _project.value ?: return
        val next = change(current).copy(updatedAt = System.currentTimeMillis())
        if (next.copy(updatedAt = 0L) == current.copy(updatedAt = 0L)) return
        undoStack.addLast(current)
        if (undoStack.size > 100) undoStack.removeFirst()
        redoStack.clear()
        apply(next)
    }

    fun undo() {
        val prev = undoStack.removeLastOrNull() ?: return
        _project.value?.let { redoStack.addLast(it) }
        apply(prev)
    }

    fun redo() {
        val next = redoStack.removeLastOrNull() ?: return
        _project.value?.let { undoStack.addLast(it) }
        apply(next)
    }

    private fun apply(next: Project) {
        _project.value = next
        refreshFlags()
        rebuildPlaylist(force = false)
        persist(next)
        if (playhead.value > next.totalDurationMs()) playhead.value = next.totalDurationMs()
        val sel = selectedClipId.value
        if (sel != null && next.clips.none { it.id == sel }) selectedClipId.value = null
    }

    private fun refreshFlags() {
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = redoStack.isNotEmpty()
    }

    private fun persist(p: Project) {
        saveJob?.cancel()
        saveJob = viewModelScope.launch(Dispatchers.IO) {
            delay(300)
            store.save(p)
        }
    }

    // ---------- Clip editing ----------

    fun selectClip(id: String?) {
        selectedClipId.value = id
    }

    fun updateClip(id: String, transform: (Clip) -> Clip) = commit { p ->
        p.copy(clips = p.clips.map { if (it.id == id) transform(it) else it })
    }

    fun trimClip(id: String, inMs: Long, outMs: Long) = updateClip(id) { c ->
        val src = c.sourceDurationMs
        val i = inMs.coerceIn(0L, (src - MIN_CLIP_MS).coerceAtLeast(0L))
        val o = outMs.coerceIn(i + MIN_CLIP_MS, src.coerceAtLeast(i + MIN_CLIP_MS))
        c.copy(inMs = i, outMs = o)
    }

    fun setCrop(id: String, ratio: String) = updateClip(id) { it.copy(crop = ratio) }

    fun setAdjust(id: String, adjust: Adjust) = updateClip(id) { it.copy(adjust = adjust) }

    fun toggleEffect(clipId: String, type: EffectType) = updateClip(clipId) { c ->
        if (c.effects.any { it.type == type }) {
            c.copy(effects = c.effects.filterNot { it.type == type })
        } else {
            c.copy(effects = c.effects + ClipEffect(type, 0.6f))
        }
    }

    fun setEffectAmount(clipId: String, type: EffectType, amount: Float) = updateClip(clipId) { c ->
        c.copy(effects = c.effects.map { if (it.type == type) it.copy(amount = amount) else it })
    }

    fun addKeyframe(clipId: String, property: String, value: Float) {
        val p = _project.value ?: return
        val pl = p.placementAt(playhead.value)
        if (pl == null || pl.clip.id != clipId) {
            _message.tryEmit("Move the playhead over this clip first.")
            return
        }
        val t = playhead.value - pl.startMs
        updateClip(clipId) { c ->
            c.copy(keyframes = c.keyframes.filterNot { it.timeMs == t && it.property == property } + Keyframe(t, property, value))
        }
    }

    fun deleteClip(id: String) {
        commit { p -> p.copy(clips = p.clips.filterNot { it.id == id }) }
        selectedClipId.value = null
    }

    fun moveSelected(delta: Int) {
        val id = selectedClipId.value ?: return
        commit { p ->
            val idx = p.clips.indexOfFirst { it.id == id }
            val to = idx + delta
            if (idx < 0 || to !in p.clips.indices) {
                p
            } else {
                val list = p.clips.toMutableList()
                val moved = list.removeAt(idx)
                list.add(to, moved)
                p.copy(clips = list)
            }
        }
    }

    fun splitAtPlayhead() {
        val p = _project.value ?: return
        val pl = p.placementAt(playhead.value) ?: return
        val c = pl.clip
        val offset = playhead.value - pl.startMs
        if (offset < MIN_CLIP_MS || c.durationMs - offset < MIN_CLIP_MS) {
            _message.tryEmit("Move the playhead inside the clip to split it.")
            return
        }
        val splitAt = c.inMs + offset
        val left = c.copy(
            id = newId(),
            outMs = splitAt,
            keyframes = c.keyframes.filter { it.timeMs < offset },
        )
        val right = c.copy(
            id = newId(),
            inMs = splitAt,
            keyframes = c.keyframes.filter { it.timeMs >= offset }.map { it.copy(timeMs = it.timeMs - offset) },
        )
        commit { proj ->
            proj.copy(clips = proj.clips.flatMap { if (it.id == c.id) listOf(left, right) else listOf(it) })
        }
        selectedClipId.value = right.id
    }

    // ---------- Layers ----------

    fun addText() {
        commit { p ->
            p.copy(texts = p.texts + TextLayer(text = "Title", startMs = playhead.value, durationMs = TEXT_DEFAULT_MS))
        }
    }

    // ---------- Zoom ----------

    fun setZoom(dp: Float) {
        zoomDp.value = dp.coerceIn(12f, 240f)
    }

    fun zoomBy(factor: Float) = setZoom(zoomDp.value * factor)

    // ---------- Playback ----------

    fun togglePlay() = if (isPlaying.value) pause() else play()

    fun play() {
        val p = _project.value ?: return
        if (p.clips.isEmpty()) return
        if (playhead.value >= p.totalDurationMs()) playhead.value = 0L
        isPlaying.value = true
        lastClipId = null
        startTicker()
    }

    fun pause() {
        isPlaying.value = false
        player.pause()
    }

    fun seekTo(ms: Long) {
        val p = _project.value ?: return
        val t = ms.coerceIn(0L, p.totalDurationMs())
        playhead.value = t
        lastClipId = null
        val pl = p.placementAt(t)
        if (pl != null && !pl.clip.isImage) {
            val vIdx = p.videoClips().indexOfFirst { it.id == pl.clip.id }
            if (vIdx >= 0) player.seekTo(vIdx, t - pl.startMs)
        }
        if (!isPlaying.value) player.pause()
    }

    private fun startTicker() {
        if (ticker?.isActive == true) return
        ticker = viewModelScope.launch {
            var last = System.nanoTime()
            while (isActive && isPlaying.value) {
                delay(16)
                val now = System.nanoTime()
                val dtMs = (now - last) / 1_000_000L
                last = now
                advance(dtMs)
            }
        }
    }

    /** The playhead is the clock. Video clips follow it, and the player is re-synced when it drifts. */
    private fun advance(dtMs: Long) {
        val p = _project.value
        if (p == null) {
            pause()
            return
        }
        val total = p.totalDurationMs()
        val next = playhead.value + dtMs
        if (next >= total) {
            playhead.value = total
            pause()
            return
        }
        playhead.value = next
        val pl = p.placementAt(next) ?: return
        val clip = pl.clip
        if (clip.isImage) {
            if (player.isPlaying) player.pause()
            lastClipId = clip.id
            return
        }
        val vIdx = p.videoClips().indexOfFirst { it.id == clip.id }
        if (vIdx < 0) return
        val offset = next - pl.startMs
        if (lastClipId != clip.id) {
            player.seekTo(vIdx, offset)
            lastClipId = clip.id
        } else if (player.playbackState == Player.STATE_READY &&
            (player.currentMediaItemIndex != vIdx || abs(player.currentPosition - offset) > 300)
        ) {
            player.seekTo(vIdx, offset)
        }
        if (!player.playWhenReady) player.play()
    }

    private fun rebuildPlaylist(force: Boolean) {
        val p = _project.value ?: return
        val clips = p.videoClips()
        val sig = clips.joinToString("|") { "${it.id}:${it.uri}:${it.inMs}:${it.outMs}" }
        if (!force && sig == playlistSignature) return
        playlistSignature = sig
        lastClipId = null
        val items = clips.map { c ->
            MediaItem.Builder()
                .setMediaId(c.id)
                .setUri(c.uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(c.inMs)
                        .setEndPositionMs(c.outMs)
                        .build()
                )
                .build()
        }
        player.setMediaItems(items, true)
        player.prepare()
    }

    private fun newId(): String = java.util.UUID.randomUUID().toString()

    override fun onCleared() {
        _project.value?.let { store.save(it) }
        player.release()
        super.onCleared()
    }
}
