package com.darkeffect.app.engine

import androidx.media3.common.Effect
import androidx.media3.common.MimeTypes
import androidx.media3.common.MediaItem
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.Crop
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import com.darkeffect.app.model.Clip
import com.darkeffect.app.model.EffectType
import com.darkeffect.app.model.Project
import kotlin.math.abs

/** Maps the editor's clip settings onto Media3 GL effects for export. */
object EffectFactory {

    fun forClip(clip: Clip): List<Effect> {
        val out = mutableListOf<Effect>()

        cropFor(clip)?.let { out.add(it) }

        val a = clip.adjust
        val brightness = (a.brightness + a.exposure * 0.5f).coerceIn(-1f, 1f)
        if (brightness != 0f) out.add(Brightness(brightness))
        if (a.contrast != 0f) out.add(Contrast(a.contrast.coerceIn(-1f, 1f)))
        val saturation = a.saturation.coerceIn(-1f, 1f) * 100f
        if (saturation != 0f) out.add(HslAdjustment.Builder().adjustSaturation(saturation).build())

        clip.effects.forEach { fx ->
            if (!fx.type.implemented) return@forEach
            val s = fx.amount.coerceIn(0f, 1f)
            when (fx.type) {
                EffectType.TEAL_ORANGE -> out.add(
                    RgbAdjustment.Builder().setRedScale(1f + 0.15f * s).setGreenScale(1f).setBlueScale(1f - 0.10f * s).build()
                )
                EffectType.WARM_CINEMA -> out.add(
                    RgbAdjustment.Builder().setRedScale(1f + 0.10f * s).setGreenScale(1f).setBlueScale(1f - 0.10f * s).build()
                )
                EffectType.NOIR -> {
                    out.add(HslAdjustment.Builder().adjustSaturation(-100f * s).build())
                    out.add(Contrast(0.15f * s))
                }
                else -> Unit
            }
        }
        return out
    }

    /** Center crop to the target aspect ratio using NDC bounds. */
    private fun cropFor(clip: Clip): Effect? {
        val target = when (clip.crop) {
            "16:9" -> 16f / 9f
            "9:16" -> 9f / 16f
            "1:1" -> 1f
            "4:5" -> 4f / 5f
            else -> return null
        }
        val src = clip.srcWidth.toFloat() / clip.srcHeight.toFloat()
        if (abs(src - target) < 0.01f) return null
        return if (src > target) {
            val half = target / src
            Crop(-half, half, -1f, 1f)
        } else {
            val half = src / target
            Crop(-1f, 1f, -half, half)
        }
    }
}

object ExportPlan {
    fun build(project: Project, height: Int, fps: Int): Composition {
        val items = project.clips.map { clip ->
            val mediaItem = MediaItem.Builder()
                .setUri(clip.uri)
                .apply {
                    if (clip.isImage) {
                        setImageDurationMs(clip.durationMs)
                    } else {
                        setClippingConfiguration(
                            MediaItem.ClippingConfiguration.Builder()
                                .setStartPositionMs(clip.inMs)
                                .setEndPositionMs(clip.outMs)
                                .build()
                        )
                    }
                }
                .build()
            val effects: List<Effect> = EffectFactory.forClip(clip) + Presentation.createForHeight(height)
            EditedMediaItem.Builder(mediaItem)
                .setEffects(Effects(emptyList(), effects))
                .setFrameRate(fps)
                .build()
        }
        return Composition.Builder(EditedMediaItemSequence(items)).build()
    }
}
